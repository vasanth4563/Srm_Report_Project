from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base
from .routers import auth_router, report_router, goal_router, acc_router, pending_router, weekly_router, admin_router

# Initialize tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="ReportSync API",
    description="Backend API for Daily Report Management System",
    version="2.0"
)

# Enable CORS for the React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router.router)
app.include_router(report_router.router)
app.include_router(goal_router.router)
app.include_router(acc_router.router)
app.include_router(pending_router.router)
app.include_router(weekly_router.router)
app.include_router(admin_router.router)

@app.get("/")
def read_root():
    return {"message": "ReportSync FastAPI Backend is running!"}
