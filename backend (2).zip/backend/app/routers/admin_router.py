from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(prefix="/api/admin", tags=["admin"])

@router.get("/users", response_model=List[schemas.UserReportSummary])
def get_users_report_summary(
    db: Session = Depends(get_db),
    admin: models.User = Depends(auth.get_current_admin)
):
    users = db.query(models.User).all()
    result = []
    
    for u in users:
        # Get count of total, done, and pending daily reports
        total = db.query(func.count(models.DailyReport.id)).filter(models.DailyReport.user_id == u.id).scalar() or 0
        done = db.query(func.count(models.DailyReport.id)).filter(
            models.DailyReport.user_id == u.id, 
            models.DailyReport.completed == True
        ).scalar() or 0
        pending = total - done
        
        # Display full name with title if exists (e.g. Dr. Kathiravan)
        display_name = f"{u.name}"
        
        result.append({
            "id": u.id,
            "name": display_name,
            "designation": u.designation,
            "branch": u.branch,
            "totalReports": total,
            "doneReports": done,
            "pendingReports": pending
        })
        
    return result
