from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from urllib.parse import urlparse
from .config import settings

def create_database_if_not_exists():
    try:
        parsed = urlparse(settings.DATABASE_URL)
        db_name = parsed.path.lstrip('/')
        # Reconstruct connection URL without the database name
        server_url = f"{parsed.scheme}://{parsed.netloc}"
        
        # Connect to MySQL server root
        temp_engine = create_engine(server_url)
        with temp_engine.connect() as conn:
            # Create DB if it doesn't exist
            conn.execute(text(f"CREATE DATABASE IF NOT EXISTS {db_name}"))
            conn.commit()
            
            # Run migration to add title column to users table
            try:
                conn.execute(text(f"ALTER TABLE {db_name}.users ADD COLUMN title VARCHAR(20) DEFAULT 'Mr.'"))
                conn.commit()
                print("Migration: title column added to users table.")
            except Exception as migrate_err:
                # Catch "Duplicate column" or "Table doesn't exist" and ignore
                pass
                
        temp_engine.dispose()
        print(f"MySQL Database '{db_name}' verified/created.")
    except Exception as e:
        print(f"Warning: Could not check/create database: {e}")

# Run verify/create check
create_database_if_not_exists()

# Exclusive MySQL connection (SQLite fallback disabled)
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
